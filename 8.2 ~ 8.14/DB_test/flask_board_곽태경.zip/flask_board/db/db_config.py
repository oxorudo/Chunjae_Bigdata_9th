"""
데이터베이스 설정 정보 파일
보안을 위해 따로 CONFIG 파일을 만들어 보관한다.
"""
class Config:
    HOST = "localhost"
    USERNAME = "testuser"
    PASSWORD = "Tkkwak0419?!"
    SECRET_KEY = '5NCWLXbFyhIkJqZpZxRBRPuiTOeuGrs' # 시크릿 키 생성 (무작위로 생성했다.)
    DEBUG = True # 디버거 생성 : 수정사항이 계속 반영
    DB = 'db_test'



